#!/bin/bash

# ----------------------------------------
# Config
# ----------------------------------------

# LOGFILE now includes timestamp automatically
LOGFILE="mem_system_$(date +%Y%m%d_%H%M%S).log"

# <<< EDIT THIS PART IF YOU WANT TO CHANGE FIO >>>
FIO_CMD="fio --name=fio_test \
  --filename=/media/nvme/testfile \
  --size=1G \
  --io_size=10G \
  --rw=write \
  --bs=64k \
  --iodepth=64 \
  --direct=1 \
  --numjobs=8"

# ----------------------------------------
# Start fio in background
# ----------------------------------------
echo "[INFO] starting fio..."
$FIO_CMD &
FIO_PID=$!

echo "[INFO] fio PID = $FIO_PID"
echo "# timestamp total_kb used_kb avail_kb used_pct" > "$LOGFILE"

# ----------------------------------------
# Main loop: log *system* memory every 1s
# ----------------------------------------
while ps -p "$FIO_PID" > /dev/null 2>&1; do
    ts=$(date +%Y-%m-%d_%H:%M:%S)

    read total_kb avail_kb < <(awk '
        /MemTotal/     { t = $2 }
        /MemAvailable/ { a = $2 }
        END { print t, a }
    ' /proc/meminfo)

    used_kb=$(( total_kb - avail_kb ))

    used_pct=$(awk -v u="$used_kb" -v t="$total_kb" \
        'BEGIN { printf "%.4f", (u/t)*100 }')

    echo "$ts $total_kb $used_kb $avail_kb $used_pct" >> "$LOGFILE"

    sleep 1
done

echo "[INFO] fio finished"
echo "[INFO] memory log saved to $LOGFILE"

